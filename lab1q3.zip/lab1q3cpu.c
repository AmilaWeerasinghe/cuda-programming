
#include <malloc.h>
#include <stdio.h>
#include <omp.h>

#define MatSize 65536//this is the matrix size
#define AVAL 10.0 //define a value for matrix A elemetns(Easy for testing)
#define BVAL 5.0//define a value for matrix B
#define TOL  0.001

int main(int argc, char *argv[])
{
	int Ndim, Pdim, Mdim;  //integers to indicate the legnth and height of the matrices
	int i,j,k;

	//variables to hols values
	
	double *A, *B, *C, cval, tmp, err, errsq;
      double dN, mflops;
	double start_time, run_time;//measure time

//width and height is equal
	Ndim = MatSize;
	Pdim = MatSize;
	Mdim = MatSize;

	A = (double *)malloc(Ndim*Pdim*sizeof(double));
      B = (double *)malloc(Pdim*Mdim*sizeof(double));
      C = (double *)malloc(Ndim*Mdim*sizeof(double));

	/* Initialize matrices */

	for (i=0; i<Ndim; i++)
		for (j=0; j<Pdim; j++)
			*(A+(i*Ndim+j)) = AVAL;//assign A val to all values

	for (i=0; i<Pdim; i++)
		for (j=0; j<Mdim; j++)
			*(B+(i*Pdim+j)) = BVAL;// assign B val to all elemnts

	for (i=0; i<Ndim; i++)
		for (j=0; j<Mdim; j++)
			*(C+(i*Ndim+j)) = 0.0;
	
		start_time = omp_get_wtime();//start counting time

	//perform the multiplication in parallel 
	//parallel for makes the highest avaialble threads in the different mcachines
	//parallel for takes care of the shared and private variables in the parallel zone as indicated in the code

	//parallel region
	#pragma omp parallel for private(tmp,i,j,k)
	   for(i=0;i<Ndim;i++){
		   for(j=0;j<Mdim;j++){
			   *(C+(i*Ndim+j))=*(A+(i*Ndim+j))-*(B+(i*Ndim+j));


		   }
	   }
	

	run_time = omp_get_wtime() - start_time;//take the time dif

	printf(" Matrix Size %d multiplication in %f seconds \n", MatSize, run_time);
	//print the allocated maximum number of threads;
      printf(" %d threads\n",omp_get_max_threads());
      dN = (double)MatSize;
    
	//print the answer matrix(test)

	/*for(int i=0;i<Ndim;i++){
		for(int j=0;j<Ndim;j++){
			printf("%lf ",*(C+(i*Ndim+j)));
		}
		printf("\n");
	}*/

}
